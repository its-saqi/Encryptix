import tkinter as tk
from tkinter import messagebox
import string
import random

def generate_password():
    try:
        plen = int(length_entry.get())
        if plen <= 0:
            raise ValueError("Password length must be greater than 0.")
        
        s1 = string.ascii_lowercase
        s2 = string.ascii_uppercase
        s3 = string.digits
        s4 = string.punctuation
        
        s = []
        s.extend(list(s1))
        s.extend(list(s2))
        s.extend(list(s3))
        s.extend(list(s4))
        
        password = "".join(random.sample(s, plen))
        password_label.config(text=f"Your password is: {password}")
    except ValueError as ve:
        messagebox.showerror("Invalid Input", str(ve))

# Set up the main application window
root = tk.Tk()
root.title("Password Generator")

# Create a frame for the input and button
frame = tk.Frame(root)
frame.pack(pady=20)

# Create an entry widget for password length
length_label = tk.Label(frame, text="Enter password length:")
length_label.grid(row=0, column=0, padx=10)

length_entry = tk.Entry(frame)
length_entry.grid(row=0, column=1, padx=10)

# Create a button to generate the password
# generate_button = tk.Button(frame, text="Password", command=generate_password)

generate_button = tk.Button(frame, text="Password", command=generate_password)
generate_button.grid(row=0, column=2, padx=10)
# Create a label to display the generated password
password_label = tk.Label(root, text="")
password_label.pack(pady=20)

# Run the application
root.mainloop()
